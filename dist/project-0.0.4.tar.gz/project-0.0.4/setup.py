from setuptools import setup

setup(
    name="project",
    version="0.0.4",
    description="mi primer paquete",
    author="gusun0",
    author_email="ejemplo@gmail.com",
    url="",
    scripts=[],
    packages=["Paquetes","Paquetes.op1","Paquetes.op2"]
)

